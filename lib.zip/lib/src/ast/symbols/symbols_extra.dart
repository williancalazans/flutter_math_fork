// These symbols are too complex, we need to store their widget
// const complexSymbolRenderResult = {
//   // Stacked operator
//   '\u2258',
//   '\u2259',
//   '\u225A',
//   '\u225B',
//   '\u225D', //\defeq
//   '\u225E',
//   '\u225F',

//   // Circled char
//   '\u00A9',
// };

const decoratedEqualSymbols = {
  // '\u2258',
  '\u2259',
  '\u225A',
  '\u225B',
  '\u225D',
  '\u225E',
  '\u225F',
};
