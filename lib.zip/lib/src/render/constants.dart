import 'package:flutter/cupertino.dart';
import '../ast/size.dart';

const infiniteConstraint = BoxConstraints();

const nullDelimiterSpace = Measurement(value: 0.12, unit: Unit.cssEm);
