/// Mode for widget
enum FlutterMathMode {
  /// Editable (Unimplemented)
  edit,

  /// Selectable
  select,

  /// Non-selectable
  view,
}
